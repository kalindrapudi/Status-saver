# Status Saver (ad-free, private)

A small Android app (about 30 KB of code, no libraries) that:

- **WhatsApp + WhatsApp Business:** shows the statuses you have already viewed, lets you preview, save and share them. Works offline.
- **Saved tab:** everything you saved (Gallery > Pictures/StatusSaver and Movies/StatusSaver).
- **Insta / FB button:** a built-in browser. Log in yourself, open a story, post or profile picture, tap **Save**, and it saves the biggest photo or video on screen at full quality. You can also long-press any normal picture.

It has no ads, no analytics and no trackers. The only permission is Internet, which only the Insta / FB browser uses. Your login stays inside Android's own WebView, and the app never sees your password.

Needs Android 10 or newer.

## Get the APK, option A: GitHub (no laptop needed)

1. Create a free account at github.com and a new **empty** repository (for example `status-saver`).
2. Upload this whole folder, keeping the folder structure, including the hidden `.github` folder.
3. Open the **Actions** tab. The "Build APK" job runs automatically and takes about 4 minutes.
4. Open the finished run, then under **Artifacts** download `StatusSaver-apk`. It is a zip containing `app-release.apk`.
5. On your phone, open the APK and allow "Install unknown apps" for your browser or file manager.

## Get the APK, option B: Android Studio (laptop)

1. Install Android Studio and open this folder (**File > Open**).
2. Let it sync, which downloads the SDK automatically the first time.
3. Choose **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. Copy `app/build/outputs/apk/debug/app-debug.apk` to your phone and install it.

## First use

- Open the **WhatsApp** tab and tap **Allow folder access**. The `.Statuses` folder opens pre-selected, so tap **Use this folder** and then **Allow**. You only do this once. Do the same for **WA Business** if you use it.
- Tap a status to preview it, then tap Save or Share. **Long-press** a status to save it instantly.
- **Long-press a tab** (WhatsApp or WA Business) to choose the folder again if needed.

## Honest limits

- WhatsApp only keeps statuses you have **viewed**, and only for 24 hours. Save the ones you want before they expire.
- Instagram and Facebook videos are often streamed in small pieces (shown as `blob:`). Those can't be downloaded, and the app tells you to use the screen recorder instead. Photos, profile pictures and many videos do work.
- Instagram and Facebook change their websites often, so the Save button may need small updates over time. Meta's terms don't allow automated downloading, so use it only for personal saving, and ask before reposting someone else's content.

## How it was designed

It uses the same approach as open-source savers on GitHub and F-Droid (for example GauthamAsir/WhatsApp_Status_Saver, z1nc0r3/GetsTatus and theapache64/whatsapp-status-browser). Since Android 11, the only reliable way to read statuses is the system folder picker (Storage Access Framework) with the `.Statuses` folder pre-selected, and that is what this app uses. No closed-source app was decompiled.
